package com.y2k.player

import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

val Context.ds by preferencesDataStore("chromedeck")

data class Profile(
    val id: String,
    val name: String,
    val theme: Int = 2,
    val accent: Int = 0xFF4D7CFF.toInt(),
    val bg: Int = 0,
    val calm: Boolean = false,
    val pic: String? = null,
    val last: String? = null
)

class Th(val name: String, val top: Color, val bot: Color, val panel: Color, val r: Int)

val THEMES = listOf(
    Th("PS2 Retro", Color(0xFF0A1040), Color(0xFF000000), Color(0x33AAB4FF), 6),
    Th("PS Vita", Color(0xFF1479C9), Color(0xFF2EC4B6), Color(0x40FFFFFF), 28),
    Th("PS5 Futuristic", Color(0xFF1B1D24), Color(0xFF0B0C10), Color(0x1AFFFFFF), 20),
    Th("Y2K Chrome", Color(0xFF2A1250), Color(0xFF05050A), Color(0x33C8D0E0), 14)
)
val BGS = listOf("Gradient", "Solid", "Grid")
val PRESETS = listOf(0xFF2F6BFF, 0xFFDC143C, 0xFF8A2BE2, 0xFF39FF14, 0xFFFF2E93, 0xFFC0C0C8, 0xFF00E5FF).map { Color(it) }

object Store {
    private val K = stringPreferencesKey("profiles")

    fun flow(c: Context) = c.ds.data.map { p ->
        val a = JSONArray(p[K] ?: "[]")
        List(a.length()) { i ->
            val o = a.getJSONObject(i)
            Profile(
                o.getString("id"), o.getString("name"), o.optInt("theme"), o.optInt("accent"),
                o.optInt("bg"), o.optBoolean("calm"),
                o.optString("pic").ifEmpty { null }, o.optString("last").ifEmpty { null }
            )
        }
    }

    suspend fun save(c: Context, l: List<Profile>) {
        c.ds.edit { e ->
            e[K] = JSONArray(l.map { p ->
                JSONObject().put("id", p.id).put("name", p.name).put("theme", p.theme)
                    .put("accent", p.accent).put("bg", p.bg).put("calm", p.calm)
                    .put("pic", p.pic ?: "").put("last", p.last ?: "")
            }).toString()
        }
    }
}
