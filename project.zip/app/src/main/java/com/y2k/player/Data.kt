package com.y2k.player

import android.content.Context
import android.graphics.Typeface
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

val Context.ds by preferencesDataStore("chromedeck")

data class Profile(
    val id: String, val name: String, val theme: Int = 2, val accent: Int = 0xFF39FF14.toInt(),
    val bg: Int = 0, val anim: Int = 2, val pic: String? = null, val last: String? = null,
    val shape: Int = 1, val bgm: String? = null, val compact: Boolean = false, val click: Boolean = false
)

class Th(val name: String, val top: Color, val bot: Color, val panel: Color, val r: Int, val font: FontFamily, val ls: Float)

private fun tf(n: String, s: Int = Typeface.NORMAL) = FontFamily(Typeface.create(n, s))
val SERPENT = tf("sans-serif-black", Typeface.BOLD_ITALIC)

val THEMES = listOf(
    Th("PS2 Retro", Color(0xFF0A1040), Color(0xFF000000), Color(0x33AAB4FF), 6, tf("sans-serif-condensed"), 1.6f),
    Th("PS Vita", Color(0xFF1479C9), Color(0xFF2EC4B6), Color(0x40FFFFFF), 28, tf("sans-serif-medium"), .2f),
    Th("PS5 Futuristic", Color(0xFF1B1D24), Color(0xFF0B0C10), Color(0x1AFFFFFF), 20, tf("sans-serif-light"), .6f),
    Th("Y2K Chrome", Color(0xFF2A1250), Color(0xFF05050A), Color(0x33C8D0E0), 14, FontFamily.Monospace, .8f)
)
val BRAND = Profile("brand", "", 2)
val BGS = listOf("Gradient", "Solid", "Grid", "Photo / GIF")
val SHAPES = listOf("Square", "Rounded", "Circle")
val ANIMS = listOf("Off", "Low", "High")
val PRESETS = listOf(0xFF39FF14, 0xFF2F6BFF, 0xFFDC143C, 0xFF8A2BE2, 0xFFFF2E93, 0xFFC0C0C8, 0xFF00E5FF).map { Color(it) }

object Store {
    private val K = stringPreferencesKey("profiles")

    fun flow(c: Context) = c.ds.data.map { p ->
        val a = JSONArray(p[K] ?: "[]")
        List(a.length()) { i ->
            val o = a.getJSONObject(i)
            Profile(
                id = o.getString("id"), name = o.getString("name"), theme = o.optInt("theme", 2),
                accent = o.optInt("accent", 0xFF39FF14.toInt()), bg = o.optInt("bg"),
                anim = if (o.has("anim")) o.optInt("anim") else if (o.optBoolean("calm")) 0 else 2,
                pic = o.optString("pic").ifEmpty { null }, last = o.optString("last").ifEmpty { null },
                shape = o.optInt("shape", 1), bgm = o.optString("bgm").ifEmpty { null },
                compact = o.optBoolean("compact"), click = o.optBoolean("click")
            )
        }
    }

    suspend fun save(c: Context, l: List<Profile>) {
        c.ds.edit { e ->
            e[K] = JSONArray(l.map { p ->
                JSONObject().put("id", p.id).put("name", p.name).put("theme", p.theme).put("accent", p.accent)
                    .put("bg", p.bg).put("anim", p.anim).put("pic", p.pic ?: "").put("last", p.last ?: "")
                    .put("shape", p.shape).put("bgm", p.bgm ?: "").put("compact", p.compact).put("click", p.click)
            }).toString()
        }
    }
}
