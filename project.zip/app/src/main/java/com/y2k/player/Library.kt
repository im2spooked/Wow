package com.y2k.player

import android.Manifest
import android.content.ComponentName
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.util.LruCache
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class Track(val uri: String, val title: String, val artist: String, val album: String, val dur: Long, val art: String?, val fav: Boolean = false)

class Db(c: Context) : SQLiteOpenHelper(c, "lib.db", null, 3) {
    private val ddl = listOf(
        "CREATE TABLE IF NOT EXISTS pl(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT)",
        "CREATE TABLE IF NOT EXISTS plt(pid INTEGER,uri TEXT,pos INTEGER)",
        "CREATE TABLE IF NOT EXISTS hist(uri TEXT,t INTEGER)",
        "CREATE TABLE IF NOT EXISTS online(id TEXT PRIMARY KEY,kind INTEGER,title TEXT,author TEXT,art TEXT,url TEXT,added INTEGER)"
    )
    private val cols = "t.uri,t.title,t.artist,t.album,t.dur,t.art,t.fav"
    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE tracks(uri TEXT PRIMARY KEY,title TEXT,artist TEXT,album TEXT,dur INTEGER,art TEXT,fav INTEGER DEFAULT 0,added INTEGER)")
        ddl.forEach { d.execSQL(it) }
    }
    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) { ddl.forEach { d.execSQL(it) } }
    private fun q(sql: String, a: Array<String>? = null): List<Track> =
        readableDatabase.rawQuery(sql, a).use { c ->
            val l = ArrayList<Track>()
            while (c.moveToNext()) l.add(Track(c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getLong(4), c.getString(5), c.getInt(6) == 1))
            l
        }
    fun all() = q("SELECT $cols FROM tracks t ORDER BY t.title COLLATE NOCASE")
    fun recents() = q("SELECT $cols FROM tracks t JOIN (SELECT uri,MAX(t) m FROM hist GROUP BY uri) h ON h.uri=t.uri ORDER BY h.m DESC LIMIT 50")
    fun plTracks(id: Long) = q("SELECT $cols FROM plt p JOIN tracks t ON t.uri=p.uri WHERE p.pid=? ORDER BY p.pos", arrayOf(id.toString()))
    fun playlists(): List<Pair<Long, String>> =
        readableDatabase.rawQuery("SELECT id,name FROM pl ORDER BY name COLLATE NOCASE", null).use { c ->
            val l = ArrayList<Pair<Long, String>>()
            while (c.moveToNext()) l.add(c.getLong(0) to c.getString(1))
            l
        }
    fun newPl(n: String): Long = writableDatabase.insert("pl", null, ContentValues().apply { put("name", n) })
    fun delPl(id: Long) {
        writableDatabase.delete("pl", "id=?", arrayOf(id.toString()))
        writableDatabase.delete("plt", "pid=?", arrayOf(id.toString()))
    }
    fun addTo(id: Long, u: String) {
        val d = writableDatabase
        d.rawQuery("SELECT 1 FROM plt WHERE pid=? AND uri=?", arrayOf(id.toString(), u)).use { if (it.moveToFirst()) return }
        val n = d.compileStatement("SELECT COUNT(*) FROM plt WHERE pid=$id").simpleQueryForLong()
        d.insert("plt", null, ContentValues().apply { put("pid", id); put("uri", u); put("pos", n) })
    }
    fun rmFrom(id: Long, u: String) { writableDatabase.delete("plt", "pid=? AND uri=?", arrayOf(id.toString(), u)) }
    fun fav(u: String, v: Boolean) { writableDatabase.execSQL("UPDATE tracks SET fav=? WHERE uri=?", arrayOf<Any>(if (v) 1 else 0, u)) }
    fun hist(u: String) { writableDatabase.insert("hist", null, ContentValues().apply { put("uri", u); put("t", System.currentTimeMillis()) }) }
    fun onlineAll(): List<Ol> =
        readableDatabase.rawQuery("SELECT id,kind,title,author,art,url FROM online ORDER BY added DESC", null).use { c ->
            val l = ArrayList<Ol>()
            while (c.moveToNext()) l.add(Ol(c.getString(0), c.getInt(1), c.getString(2), c.getString(3), c.getString(4), c.getString(5)))
            l
        }
    fun onlineHas(id: String): Boolean = readableDatabase.rawQuery("SELECT 1 FROM online WHERE id=?", arrayOf(id)).use { it.moveToFirst() }
    fun onlinePut(o: Ol) {
        val v = ContentValues().apply {
            put("id", o.id); put("kind", o.kind); put("title", o.title); put("author", o.author)
            put("art", o.art); put("url", o.url); put("added", System.currentTimeMillis())
        }
        writableDatabase.insertWithOnConflict("online", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun onlineDel(id: String) { writableDatabase.delete("online", "id=?", arrayOf(id)) }
    fun clearHist() { writableDatabase.delete("hist", null, null) }
    fun has(u: String): Boolean = readableDatabase.rawQuery("SELECT 1 FROM tracks WHERE uri=?", arrayOf(u)).use { it.moveToFirst() }
    fun put(t: Track) {
        val v = ContentValues().apply {
            put("uri", t.uri); put("title", t.title); put("artist", t.artist); put("album", t.album)
            put("dur", t.dur); put("art", t.art); put("added", System.currentTimeMillis())
        }
        writableDatabase.insertWithOnConflict("tracks", null, v, SQLiteDatabase.CONFLICT_IGNORE)
    }
}

fun saveArt(c: Context, u: Uri, b: ByteArray): String? {
    try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(b, 0, b.size, o)
        var s = 1
        while (maxOf(o.outWidth, o.outHeight) / s > 512) s *= 2
        val bm = BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
        val k = 256f / maxOf(bm.width, bm.height)
        val out = if (k < 1f) Bitmap.createScaledBitmap(bm, (bm.width * k).toInt(), (bm.height * k).toInt(), true) else bm
        val f = File(File(c.filesDir, "art").apply { mkdirs() }, "${u.toString().hashCode()}.jpg")
        f.outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 80, it) }
        return f.path
    } catch (e: Exception) {
        return null
    }
}

fun importOne(c: Context, db: Db, u: Uri) {
    try { c.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) {}
    if (db.has(u.toString())) return
    val fn = c.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
        ?.use { if (it.moveToFirst()) it.getString(0) else null }?.substringBeforeLast('.') ?: "Unknown track"
    var t = Track(u.toString(), fn, "Unknown artist", "Unknown album", 0L, null)
    val r = MediaMetadataRetriever()
    try {
        r.setDataSource(c, u)
        fun m(k: Int) = r.extractMetadata(k)?.takeIf { it.isNotBlank() }
        val art = r.embeddedPicture?.let { saveArt(c, u, it) }
        t = Track(
            u.toString(), m(MediaMetadataRetriever.METADATA_KEY_TITLE) ?: fn,
            m(MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: "Unknown artist",
            m(MediaMetadataRetriever.METADATA_KEY_ALBUM) ?: "Unknown album",
            m(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L, art
        )
    } catch (e: Exception) {
    } finally {
        r.release()
    }
    db.put(t)
}

fun Track.item(): MediaItem {
    val a = art
    val md = MediaMetadata.Builder().setTitle(title).setArtist(artist).setAlbumTitle(album)
    if (a != null) md.setArtworkUri(Uri.fromFile(File(a)))
    return MediaItem.Builder().setUri(uri).setMediaId(uri).setMediaMetadata(md.build()).build()
}

fun fmt(ms: Long): String { val s = maxOf(0L, ms) / 1000; return "%d:%02d".format(s / 60, s % 60) }

object ArtCache : LruCache<String, Bitmap>(4096) {
    override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
}

@Stable
class Pst {
    var ctl by mutableStateOf<MediaController?>(null)
    var playing by mutableStateOf(false)
    var id by mutableStateOf("")
    var title by mutableStateOf("")
    var artist by mutableStateOf("")
    var art by mutableStateOf<String?>(null)
    var pos by mutableLongStateOf(0L)
    var dur by mutableLongStateOf(0L)
    var shuffle by mutableStateOf(false)
    var rep by mutableIntStateOf(0)
    var has by mutableStateOf(false)
    var err by mutableStateOf<String?>(null)

    fun sync(p: Player) {
        playing = p.isPlaying
        id = p.currentMediaItem?.mediaId ?: ""
        val md = p.mediaMetadata
        title = md.title?.toString() ?: ""
        artist = md.artist?.toString() ?: ""
        art = md.artworkUri?.path
        dur = if (p.duration > 0) p.duration else 0L
        pos = p.currentPosition
        shuffle = p.shuffleModeEnabled
        rep = p.repeatMode
        has = p.mediaItemCount > 0
    }
}

@Composable
fun rememberPst(onPlayed: (String, String) -> Unit): Pst {
    val c = LocalContext.current
    val st = remember { Pst() }
    val cb by rememberUpdatedState(onPlayed)
    DisposableEffect(Unit) {
        val f = MediaController.Builder(c, SessionToken(c, ComponentName(c, PlaybackService::class.java))).buildAsync()
        val l = object : Player.Listener {
            override fun onEvents(p: Player, e: Player.Events) { st.sync(p) }
            override fun onMediaItemTransition(m: MediaItem?, r: Int) { if (m != null) cb(m.mediaMetadata.title?.toString() ?: "", m.mediaId) }
            override fun onPlayerError(e: PlaybackException) {
                st.err = "Can't play that file. It may be moved, deleted, or unsupported."
                st.ctl?.let { if (it.hasNextMediaItem()) { it.seekToNextMediaItem(); it.prepare(); it.play() } }
            }
        }
        f.addListener({
            try { val m = f.get(); st.ctl = m; m.addListener(l); st.sync(m) } catch (e: Exception) {}
        }, ContextCompat.getMainExecutor(c))
        onDispose { st.ctl?.removeListener(l); st.ctl = null; MediaController.releaseFuture(f) }
    }
    return st
}

@Composable
fun Art(path: String?, sz: Dp, t: Th, ac: Color) {
    val bmp by produceState<Bitmap?>(null, path) {
        value = path?.let { p -> ArtCache.get(p) ?: withContext(Dispatchers.IO) { BitmapFactory.decodeFile(p)?.also { ArtCache.put(p, it) } } }
    }
    val sh = RoundedCornerShape(t.r.dp)
    Box(Modifier.size(sz).clip(sh).background(ac.copy(alpha = .3f)), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text("♪", color = Color.White, fontSize = (sz.value / 2.2f).sp)
    }
}

@Composable
fun Ico(k: Int, sz: Dp, col: Color, f: () -> Unit) {
    Canvas(Modifier.size(sz).clip(RoundedCornerShape(50)).clickable(onClick = f)) {
        val w = size.width
        val h = size.height
        when (k) {
            0 -> drawPath(Path().apply { moveTo(w * .32f, h * .2f); lineTo(w * .32f, h * .8f); lineTo(w * .8f, h * .5f); close() }, col)
            1 -> { drawRect(col, Offset(w * .26f, h * .2f), Size(w * .17f, h * .6f)); drawRect(col, Offset(w * .57f, h * .2f), Size(w * .17f, h * .6f)) }
            2 -> { drawPath(Path().apply { moveTo(w * .2f, h * .25f); lineTo(w * .2f, h * .75f); lineTo(w * .65f, h * .5f); close() }, col); drawRect(col, Offset(w * .7f, h * .25f), Size(w * .1f, h * .5f)) }
            else -> { drawPath(Path().apply { moveTo(w * .8f, h * .25f); lineTo(w * .8f, h * .75f); lineTo(w * .35f, h * .5f); close() }, col); drawRect(col, Offset(w * .2f, h * .25f), Size(w * .1f, h * .5f)) }
        }
    }
}

@Composable
fun FullPlayer(st: Pst, p: Profile, t: Th, ac: Color, fav: Boolean, onFav: () -> Unit, onClose: () -> Unit) {
    LaunchedEffect(st.playing) {
        while (true) {
            st.ctl?.let { st.pos = it.currentPosition }
            if (!st.playing) break
            delay(500)
        }
    }
    val sc by animateFloatAsState(if (st.playing) 1f else .9f, if (p.anim == 0) snap<Float>() else spring(), label = "art")
    var drag by remember { mutableStateOf<Float?>(null) }
    val d = maxOf(st.dur, 1L)
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(Modifier.fillMaxWidth()) { Chip("Back to library", false, ac, onClose) }
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Box(Modifier.scale(sc)) { Art(st.art, 290.dp, t, ac) }
        }
        Text(st.title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 2)
        Text(st.artist, color = ac, maxLines = 1)
        Slider(
            value = drag ?: (st.pos.toFloat() / d).coerceIn(0f, 1f),
            onValueChange = { drag = it },
            onValueChangeFinished = { drag?.let { v -> st.ctl?.seekTo((v * d).toLong()) }; drag = null },
            colors = SliderDefaults.colors(thumbColor = ac, activeTrackColor = ac)
        )
        Row(Modifier.fillMaxWidth()) {
            Text(fmt(st.pos), color = Color.White.copy(alpha = .7f), fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text("-" + fmt(st.dur - st.pos), color = Color.White.copy(alpha = .7f), fontSize = 13.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(28.dp), verticalAlignment = Alignment.CenterVertically) {
            Ico(3, 52.dp, Color.White) { st.ctl?.seekToPrevious() }
            Ico(if (st.playing) 1 else 0, 76.dp, ac) { st.ctl?.let { if (it.isPlaying) it.pause() else it.play() } }
            Ico(2, 52.dp, Color.White) { st.ctl?.seekToNext() }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip(if (fav) "♥ Favorite" else "♡ Favorite", fav, ac, onFav)
            Chip(if (st.shuffle) "Shuffle on" else "Shuffle off", st.shuffle, ac) { st.ctl?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
            Chip(listOf("Repeat off", "Repeat one", "Repeat all")[st.rep], st.rep != 0, ac) {
                st.ctl?.let { it.repeatMode = when (it.repeatMode) { 0 -> 2; 2 -> 1; else -> 0 } }
            }
        }
    }
}
