package com.y2k.player

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { App() } }
    }
}

sealed interface Scr
object Pick : Scr
data class Edit(val p: Profile?) : Scr
data class Home(val p: Profile) : Scr

@Composable
fun App() {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    val list by remember { Store.flow(c) }.collectAsState(initial = null)
    var scr by remember { mutableStateOf<Scr>(Pick) }
    val profiles = list
    if (profiles == null) {
        Box(Modifier.fillMaxSize().background(Color.Black))
        return
    }
    BackHandler(scr !is Pick) { scr = Pick }
    fun save(l: List<Profile>) { scope.launch { Store.save(c, l) } }
    when (val s = scr) {
        Pick -> Picker(profiles, { scr = Home(it) }, { scr = Edit(null) }, { scr = Edit(it) })
        is Edit -> Editor(
            s.p,
            onSave = { p ->
                save(if (profiles.any { it.id == p.id }) profiles.map { if (it.id == p.id) p else it } else profiles + p)
                scr = Home(p)
            },
            onDelete = { old ->
                old.pic?.let { File(c.filesDir, it).delete() }
                old.bgm?.let { File(c.filesDir, it).delete() }
                save(profiles.filter { it.id != old.id })
                scr = Pick
            }
        )
        is Home -> {
            val cur = profiles.firstOrNull { it.id == s.p.id } ?: s.p
            Shell(
                cur, { scr = Pick }, { scr = Edit(cur) },
                { n -> save(profiles.map { if (it.id == n.id) n else it }) },
                { t -> save(profiles.map { if (it.id == cur.id) it.copy(last = t) else it }) }
            )
        }
    }
}

@Composable
fun Picker(ps: List<Profile>, onOpen: (Profile) -> Unit, onNew: () -> Unit, onEdit: (Profile) -> Unit) {
    var chosen by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(chosen) {
        val id = chosen ?: return@LaunchedEffect
        delay(560)
        ps.firstOrNull { it.id == id }?.let(onOpen)
    }
    Backdrop(BRAND) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Wordmark(28.sp)
            Text("Who's listening?", color = Color.White.copy(alpha = .7f), modifier = Modifier.padding(top = 6.dp, bottom = 30.dp))
            LazyRow(
                contentPadding = PaddingValues(horizontal = 28.dp),
                horizontalArrangement = Arrangement.spacedBy(20.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically
            ) {
                itemsIndexed(ps, key = { _, p -> p.id }) { i, p -> ProfileCard(i, p, chosen, { chosen = p.id }, { onEdit(p) }) }
                item { NewCard(chosen != null, onNew) }
            }
        }
    }
}

@Composable
fun ProfileCard(i: Int, p: Profile, chosen: String?, onPick: () -> Unit, onEdit: () -> Unit) {
    val th = THEMES[p.theme]
    val ac = Color(p.accent)
    val sel = chosen == p.id
    val other = chosen != null && !sel
    val s by animateFloatAsState(if (sel) 1.16f else if (other) .88f else 1f, if (p.anim == 0) snap<Float>() else spring(dampingRatio = .6f, stiffness = 220f), label = "s")
    val a by animateFloatAsState(if (other) 0f else 1f, if (p.anim == 0) snap<Float>() else tween(350), label = "a")
    val g by animateFloatAsState(if (sel) 1f else 0f, tween(400), label = "g")
    val bob = rememberInfiniteTransition(label = "bob").animateFloat(-1f, 1f, infiniteRepeatable(tween(3000 + i * 450, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "b")
    val sh = RoundedCornerShape(th.r.dp)
    Column(
        Modifier.width(150.dp)
            .graphicsLayer {
                val k = if (p.anim == 0) 0f else bob.value
                translationY = k * 7.dp.toPx() * (1 - g)
                rotationZ = k * .9f * (1 - g)
                scaleX = s; scaleY = s; alpha = a
            }
            .drawBehind { drawCircle(ac.copy(alpha = .45f * g), size.maxDimension * .85f) }
            .clip(sh).background(th.panel)
            .border((1 + 2 * g).dp, if (sel) ac else Color.White.copy(alpha = .2f), sh)
            .clickable(enabled = chosen == null, onClick = onPick).padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Avatar(p, 96.dp)
        Text(p.name, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1, modifier = Modifier.padding(top = 8.dp))
        Text(th.name, color = ac, fontSize = 12.sp)
        Text(p.last ?: "Nothing played yet", color = Color.White.copy(alpha = .6f), fontSize = 12.sp, maxLines = 1)
        Text("Edit", fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp).clickable { onEdit() }.padding(6.dp))
    }
}

@Composable
fun NewCard(fade: Boolean, onNew: () -> Unit) {
    val a by animateFloatAsState(if (fade) 0f else 1f, tween(350), label = "n")
    val sh = RoundedCornerShape(20.dp)
    val ac = Color(BRAND.accent)
    Column(
        Modifier.width(150.dp).height(190.dp).bob(5, 6f).graphicsLayer { alpha = a }.clip(sh).border(2.dp, ac, sh).clickable(enabled = !fade, onClick = onNew),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("+", fontSize = 48.sp, color = ac)
        Text("New profile")
    }
}

fun saveMedia(c: Context, uri: Uri, id: String, avatar: Boolean): String? {
    try {
        val mime = c.contentResolver.getType(uri) ?: ""
        val kind = if (avatar) "pic" else "bg"
        val ts = System.currentTimeMillis()
        if (mime == "image/gif" || mime == "image/webp") {
            val n = "${kind}_${id}_$ts.${mime.substringAfter('/')}"
            val f = File(c.filesDir, n)
            c.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            if (f.length() == 0L || f.length() > 12_000_000L) { f.delete(); return null }
            return n
        }
        val lim = if (avatar) 600 else 1600
        var b = ImageDecoder.decodeBitmap(ImageDecoder.createSource(c.contentResolver, uri)) { d, i, _ ->
            val m = maxOf(i.size.width, i.size.height)
            if (m > lim) d.setTargetSampleSize(m / lim + 1)
            d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
        if (avatar) {
            val m = minOf(b.width, b.height)
            b = Bitmap.createScaledBitmap(Bitmap.createBitmap(b, (b.width - m) / 2, (b.height - m) / 2, m, m), 256, 256, true)
        }
        val n = "${kind}_${id}_$ts.jpg"
        File(c.filesDir, n).outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        return n
    } catch (e: Exception) {
        return null
    }
}

@Composable
fun Chip(txt: String, on: Boolean, ac: Color, f: () -> Unit) {
    val sh = RoundedCornerShape(50)
    Text(
        txt,
        Modifier.clip(sh).background(if (on) ac else Color.White.copy(alpha = .12f)).clickable(onClick = f).padding(horizontal = 14.dp, vertical = 8.dp),
        color = if (on && ac.luminance() > .4f) Color.Black else Color.White, fontSize = 14.sp
    )
}

@Composable
fun Chips(opts: List<String>, sel: Int, ac: Color, f: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        opts.withIndex().chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { row.forEach { (i, s) -> Chip(s, i == sel, ac) { f(i) } } }
        }
    }
}

@Composable
fun Sl(label: String, v: Float, ac: Color, f: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.width(96.dp), fontSize = 13.sp)
        Slider(v, f, Modifier.weight(1f), colors = SliderDefaults.colors(thumbColor = ac, activeTrackColor = ac))
    }
}

@Composable
fun Wheel(ac: Color, set: (Color) -> Unit) {
    var sz by remember { mutableStateOf(IntSize.Zero) }
    val hsv = FloatArray(3).also { android.graphics.Color.colorToHSV(ac.toArgb(), it) }
    fun upd(o: Offset) {
        val a = Math.toDegrees(atan2((o.y - sz.height / 2f).toDouble(), (o.x - sz.width / 2f).toDouble())).toFloat()
        set(Color.hsv((a + 360f) % 360f, maxOf(hsv[1], .35f), maxOf(hsv[2], .35f)))
    }
    Canvas(
        Modifier.size(180.dp).onSizeChanged { sz = it }
            .pointerInput(Unit) { detectDragGestures(onDragStart = { upd(it) }) { ch, _ -> upd(ch.position) } }
            .pointerInput(Unit) { detectTapGestures { upd(it) } }
    ) {
        val w = 26.dp.toPx()
        val r = size.minDimension / 2 - w / 2
        drawCircle(Brush.sweepGradient(List(7) { Color.hsv(it * 60f, 1f, 1f) }, center), radius = r, style = Stroke(w))
        val a = Math.toRadians(hsv[0].toDouble())
        val p = Offset(center.x + r * cos(a).toFloat(), center.y + r * sin(a).toFloat())
        drawCircle(Color.White, w / 2 + 2, p)
        drawCircle(ac, w / 2 - 3, p)
    }
}

@Composable
fun Editor(init: Profile?, onSave: (Profile) -> Unit, onDelete: (Profile) -> Unit) {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    val id = remember { init?.id ?: UUID.randomUUID().toString() }
    var name by remember { mutableStateOf(init?.name ?: "") }
    var th by remember { mutableIntStateOf(init?.theme ?: 2) }
    var ac by remember { mutableStateOf(Color(init?.accent ?: BRAND.accent)) }
    var bg by remember { mutableIntStateOf(init?.bg ?: 0) }
    var an by remember { mutableIntStateOf(init?.anim ?: 2) }
    var pic by remember { mutableStateOf(init?.pic) }
    var bgm by remember { mutableStateOf(init?.bgm) }
    var shape by remember { mutableIntStateOf(init?.shape ?: 1) }
    var compact by remember { mutableStateOf(init?.compact ?: false) }
    var click by remember { mutableStateOf(init?.click ?: false) }
    val live = Profile(id, name, th, ac.toArgb(), bg, an, pic, init?.last, shape, bgm, compact, click)
    fun rm(n: String?) { if (n != null) File(c.filesDir, n).delete() }
    val img = PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
    val pickPic = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val n = withContext(Dispatchers.IO) { saveMedia(c, uri, id, true) }
            if (n != null) { if (pic != init?.pic) rm(pic); pic = n }
        }
    }
    val pickBg = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val n = withContext(Dispatchers.IO) { saveMedia(c, uri, id, false) }
            if (n != null) { if (bgm != init?.bgm) rm(bgm); bgm = n; bg = 3 }
        }
    }
    val hsv = FloatArray(3).also { android.graphics.Color.colorToHSV(ac.toArgb(), it) }
    Backdrop(live) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(if (init == null) "New profile" else "Edit profile", fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Avatar(live, 96.dp)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("Photo or GIF", false, ac) { pickPic.launch(img) }
                    if (pic != null) Chip("Remove", false, ac) { if (pic != init?.pic) rm(pic); pic = null }
                }
            }
            OutlinedTextField(name, { if (it.length <= 20) name = it }, label = { Text("Profile name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Text("Picture shape")
            Chips(SHAPES, shape, ac) { shape = it }
            Text("Theme")
            Chips(THEMES.map { it.name }, th, ac) { th = it }
            Text("Accent color")
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Wheel(ac) { ac = it } }
            Sl("Saturation", hsv[1], ac) { ac = Color.hsv(hsv[0], it, hsv[2]) }
            Sl("Brightness", hsv[2], ac) { ac = Color.hsv(hsv[0], hsv[1], maxOf(it, .2f)) }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PRESETS.forEach { p -> Box(Modifier.size(32.dp).clip(CircleShape).background(p).border(if (p == ac) 3.dp else 1.dp, Color.White, CircleShape).clickable { ac = p }) }
            }
            Text("Background")
            Chips(BGS, bg, ac) { if (it == 3 && bgm == null) pickBg.launch(img) else bg = it }
            if (bg == 3) Chip(if (bgm == null) "Choose photo or GIF" else "Change photo or GIF", false, ac) { pickBg.launch(img) }
            Text("Animations")
            Chips(ANIMS, an, ac) { an = it }
            Text(if (an == 0) "Reduced motion: backgrounds and GIFs stay still." else "Animated backgrounds follow the theme.", fontSize = 12.sp, color = Color.White.copy(alpha = .6f))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Compact layout", Modifier.weight(1f))
                Switch(compact, { compact = it }, colors = SwitchDefaults.colors(checkedTrackColor = ac))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Menu click sound", Modifier.weight(1f))
                Switch(click, { click = it }, colors = SwitchDefaults.colors(checkedTrackColor = ac))
            }
            Button(
                onClick = {
                    if (pic != init?.pic) rm(init?.pic)
                    if (bgm != init?.bgm) rm(init?.bgm)
                    onSave(live.copy(name = name.trim()))
                },
                enabled = name.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = ac, contentColor = if (ac.luminance() > .4f) Color.Black else Color.White),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Save profile") }
            if (init != null) TextButton({ onDelete(init) }, Modifier.fillMaxWidth()) { Text("Delete profile", color = Color(0xFFFF6B6B)) }
        }
    }
}
