package com.y2k.player

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { App() } }
    }
}

sealed interface Scr
object Pick : Scr
data class Edit(val p: Profile?) : Scr
data class Home(val p: Profile) : Scr

@Composable
fun App() {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    val list by remember { Store.flow(c) }.collectAsState(initial = null)
    var scr by remember { mutableStateOf<Scr>(Pick) }
    val profiles = list
    if (profiles == null) {
        Box(Modifier.fillMaxSize().background(Color.Black))
        return
    }
    BackHandler(scr !is Pick) { scr = Pick }
    fun save(l: List<Profile>) { scope.launch { Store.save(c, l) } }
    when (val s = scr) {
        Pick -> Picker(profiles, { scr = Home(it) }, { scr = Edit(null) }, { scr = Edit(it) })
        is Edit -> Editor(
            s.p,
            onSave = { p ->
                save(if (profiles.any { it.id == p.id }) profiles.map { if (it.id == p.id) p else it } else profiles + p)
                scr = Home(p)
            },
            onDelete = { old ->
                old.pic?.let { File(c.filesDir, it).delete() }
                save(profiles.filter { it.id != old.id })
                scr = Pick
            }
        )
        is Home -> HomeScr(profiles.firstOrNull { it.id == s.p.id } ?: s.p) { scr = Pick }
    }
}

@Composable
fun Backdrop(t: Th, accent: Color, style: Int, content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier.fillMaxSize().drawBehind {
            if (style == 1) drawRect(t.bot) else drawRect(Brush.verticalGradient(listOf(t.top, t.bot)))
            if (style == 2) {
                val g = 48.dp.toPx()
                val col = accent.copy(alpha = .12f)
                var x = 0f
                while (x < size.width) { drawLine(col, Offset(x, 0f), Offset(x, size.height)); x += g }
                var y = 0f
                while (y < size.height) { drawLine(col, Offset(0f, y), Offset(size.width, y)); y += g }
            }
        }.systemBarsPadding(),
        content = content
    )
}

@Composable
fun Avatar(p: Profile?, sz: Dp, t: Th, accent: Color, pic: String? = p?.pic) {
    val c = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, pic) {
        value = pic?.let { n ->
            withContext(Dispatchers.IO) { BitmapFactory.decodeFile(File(c.filesDir, n).path)?.asImageBitmap() }
        }
    }
    val sh = RoundedCornerShape(t.r.dp)
    Box(
        Modifier.size(sz).clip(sh).background(accent.copy(alpha = .35f)).border(2.dp, accent, sh),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(
            (p?.name?.firstOrNull() ?: '+').uppercase(),
            color = Color.White, fontSize = (sz.value / 2.5f).sp, fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun Picker(ps: List<Profile>, onOpen: (Profile) -> Unit, onNew: () -> Unit, onEdit: (Profile) -> Unit) {
    val t = THEMES[2]
    val ac = Color(0xFF4D7CFF)
    Backdrop(t, ac, 0) {
        Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("CHROMEDECK", fontSize = 30.sp, fontWeight = FontWeight.Black, color = Color.White, letterSpacing = 4.sp)
            Text("Who's listening?", color = Color.White.copy(alpha = .7f), modifier = Modifier.padding(top = 4.dp, bottom = 16.dp))
            LazyVerticalGrid(
                GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(ps, key = { it.id }) { p -> ProfileCard(p, onOpen, onEdit) }
                item {
                    val sh = RoundedCornerShape(t.r.dp)
                    Column(
                        Modifier.fillMaxWidth().height(190.dp).clip(sh).border(2.dp, ac, sh)
                            .clickable { onNew() },
                        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("+", fontSize = 48.sp, color = ac)
                        Text("New profile", color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileCard(p: Profile, onOpen: (Profile) -> Unit, onEdit: (Profile) -> Unit) {
    val th = THEMES[p.theme]
    val ac = Color(p.accent)
    val src = remember { MutableInteractionSource() }
    val down by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (down) .94f else 1f, if (p.calm) snap() else spring(), label = "press")
    val sh = RoundedCornerShape(th.r.dp)
    Column(
        Modifier.fillMaxWidth().scale(sc).clip(sh).background(th.panel)
            .border(if (down) 2.dp else 1.dp, if (down) ac else Color.White.copy(alpha = .2f), sh)
            .clickable(interactionSource = src, indication = null) { onOpen(p) }
            .padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Avatar(p, 88.dp, th, ac)
        Text(p.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1, modifier = Modifier.padding(top = 8.dp))
        Text(th.name, color = ac, fontSize = 12.sp)
        Text(p.last ?: "Nothing played yet", color = Color.White.copy(alpha = .6f), fontSize = 12.sp, maxLines = 1)
        Text("Edit", color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp).clickable { onEdit(p) }.padding(6.dp))
    }
}

fun saveThumb(c: Context, uri: Uri, id: String): String? {
    try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (maxOf(o.outWidth, o.outHeight) / s > 600) s *= 2
        val d = BitmapFactory.Options().apply { inSampleSize = s }
        val b = c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, d) } ?: return null
        val m = minOf(b.width, b.height)
        val sq = Bitmap.createBitmap(b, (b.width - m) / 2, (b.height - m) / 2, m, m)
        val out = Bitmap.createScaledBitmap(sq, 256, 256, true)
        val name = "pic_${id}_${System.currentTimeMillis()}.jpg"
        File(c.filesDir, name).outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        return name
    } catch (e: Exception) {
        return null
    }
}

@Composable
fun Chip(txt: String, on: Boolean, ac: Color, f: () -> Unit) {
    val sh = RoundedCornerShape(50)
    Text(
        txt,
        Modifier.clip(sh).background(if (on) ac else Color.White.copy(alpha = .12f)).clickable(onClick = f)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        color = if (on && ac.luminance() > .4f) Color.Black else Color.White, fontSize = 14.sp
    )
}

@Composable
fun Chips(opts: List<String>, sel: Int, ac: Color, f: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        opts.withIndex().chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { (i, s) -> Chip(s, i == sel, ac) { f(i) } }
            }
        }
    }
}

@Composable
fun Wheel(ac: Color, set: (Color) -> Unit) {
    var sz by remember { mutableStateOf(IntSize.Zero) }
    val hue = remember(ac) { FloatArray(3).also { android.graphics.Color.colorToHSV(ac.toArgb(), it) }[0] }
    fun upd(o: Offset) {
        val a = Math.toDegrees(atan2((o.y - sz.height / 2f).toDouble(), (o.x - sz.width / 2f).toDouble())).toFloat()
        set(Color.hsv((a + 360f) % 360f, 1f, 1f))
    }
    Canvas(
        Modifier.size(180.dp).onSizeChanged { sz = it }
            .pointerInput(Unit) { detectDragGestures(onDragStart = { upd(it) }) { ch, _ -> upd(ch.position) } }
            .pointerInput(Unit) { detectTapGestures { upd(it) } }
    ) {
        val w = 26.dp.toPx()
        val r = size.minDimension / 2 - w / 2
        drawCircle(
            Brush.sweepGradient(List(7) { Color.hsv(it * 60f, 1f, 1f) }, center),
            radius = r, style = Stroke(w)
        )
        val a = Math.toRadians(hue.toDouble())
        val p = Offset(center.x + r * cos(a).toFloat(), center.y + r * sin(a).toFloat())
        drawCircle(Color.White, w / 2 + 2, p)
        drawCircle(ac, w / 2 - 3, p)
    }
}

@Composable
fun Editor(init: Profile?, onSave: (Profile) -> Unit, onDelete: (Profile) -> Unit) {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    val id = remember { init?.id ?: UUID.randomUUID().toString() }
    var name by remember { mutableStateOf(init?.name ?: "") }
    var th by remember { mutableIntStateOf(init?.theme ?: 2) }
    var ac by remember { mutableStateOf(Color(init?.accent ?: 0xFF4D7CFF.toInt())) }
    var bg by remember { mutableIntStateOf(init?.bg ?: 0) }
    var calm by remember { mutableStateOf(init?.calm ?: false) }
    var pic by remember { mutableStateOf(init?.pic) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val n = withContext(Dispatchers.IO) { saveThumb(c, uri, id) }
            if (n != null) {
                if (pic != init?.pic) pic?.let { File(c.filesDir, it).delete() }
                pic = n
            }
        }
    }
    val t = THEMES[th]
    Backdrop(t, ac, bg) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(if (init == null) "New profile" else "Edit profile", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Avatar(Profile(id, name), 96.dp, t, ac, pic)
                Chip("Choose photo", false, ac) { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
            }
            OutlinedTextField(name, { if (it.length <= 20) name = it }, label = { Text("Profile name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Text("Theme", color = Color.White)
            Chips(THEMES.map { it.name }, th, ac) { th = it }
            Text("Accent color", color = Color.White)
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Wheel(ac) { ac = it } }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                PRESETS.forEach { p ->
                    Box(Modifier.size(32.dp).clip(CircleShape).background(p).border(if (p == ac) 3.dp else 1.dp, Color.White, CircleShape).clickable { ac = p })
                }
            }
            Text("Background", color = Color.White)
            Chips(BGS, bg, ac) { bg = it }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Reduce motion", color = Color.White, modifier = Modifier.weight(1f))
                Switch(calm, { calm = it }, colors = SwitchDefaults.colors(checkedTrackColor = ac))
            }
            Button(
                onClick = {
                    if (pic != init?.pic) init?.pic?.let { File(c.filesDir, it).delete() }
                    onSave(Profile(id, name.trim(), th, ac.toArgb(), bg, calm, pic, init?.last))
                },
                enabled = name.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = ac, contentColor = if (ac.luminance() > .4f) Color.Black else Color.White),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Save profile") }
            if (init != null) TextButton({ onDelete(init) }, Modifier.fillMaxWidth()) { Text("Delete profile", color = Color(0xFFFF6B6B)) }
        }
    }
}

@Composable
fun HomeScr(p: Profile, onSwitch: () -> Unit) {
    val t = THEMES[p.theme]
    val ac = Color(p.accent)
    Backdrop(t, ac, p.bg) {
        Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            Avatar(p, 120.dp, t, ac)
            Text("Hey, ${p.name}", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(top = 14.dp))
            Text("${t.name} theme", color = ac)
            Text(
                "Profiles and themes are working. Music library and playback arrive in Stage 2.",
                color = Color.White.copy(alpha = .8f),
                modifier = Modifier.padding(vertical = 24.dp).clip(RoundedCornerShape(t.r.dp)).background(t.panel).padding(16.dp)
            )
            Button(onSwitch) { Text("Switch profile") }
        }
    }
}
