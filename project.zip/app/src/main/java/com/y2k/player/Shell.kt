package com.y2k.player

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.view.SoundEffectConstants
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class Rw(val title: String, val sub: String, val art: String?, val on: Boolean, val trail: List<Pair<String, () -> Unit>>, val act: () -> Unit)

val CATS = listOf("Music", "Albums", "Artists", "Playlists", "Online", "Favorites", "Recent", "Settings")

fun fadeUp(anim: Int): ContentTransform =
    if (anim == 0) EnterTransition.None togetherWith ExitTransition.None
    else (slideInVertically { it / 10 } + fadeIn(tween(260))) togetherWith fadeOut(tween(160))

@Composable
fun XmbItem(n: String, sel: Boolean, t: Th, ac: Color, anim: Int, f: () -> Unit) {
    val s by animateFloatAsState(if (sel) 1.3f else 1f, if (anim == 0) snap<Float>() else spring(stiffness = 300f), label = "x")
    Column(Modifier.clickable(onClick = f).padding(horizontal = 10.dp, vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.scale(s).size(46.dp).clip(RoundedCornerShape(t.r.dp)).background(if (sel) ac else Color.White.copy(alpha = .14f)),
            contentAlignment = Alignment.Center
        ) { Text(n.take(1), fontWeight = FontWeight.Bold, color = if (sel && ac.luminance() > .4f) Color.Black else Color.White) }
        Text(n, fontSize = 12.sp, color = Color.White.copy(alpha = if (sel) 1f else .55f), modifier = Modifier.padding(top = 10.dp))
    }
}

@Composable
fun Bubble(i: Int, n: String, anim: Int, f: () -> Unit) {
    val col = Color.hsv(((i * 47) % 360).toFloat(), .55f, .95f)
    Column(Modifier.bob(i, 7f, anim > 0).clickable(onClick = f), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(84.dp).clip(CircleShape).background(Brush.verticalGradient(listOf(col, col.copy(alpha = .55f))))
                .border(2.dp, Color.White.copy(alpha = .5f), CircleShape)
                .drawBehind { drawOval(Color.White.copy(alpha = .28f), Offset(size.width * .15f, size.height * .06f), Size(size.width * .7f, size.height * .38f)) },
            contentAlignment = Alignment.Center
        ) { Text(n.take(1), fontSize = 30.sp, fontWeight = FontWeight.Bold) }
        Text(n, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
fun RowItem(r: Rw, t: Th, ac: Color, compact: Boolean) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = r.act).padding(horizontal = 16.dp, vertical = if (compact) 2.dp else 7.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Art(r.art, if (compact) 40.dp else 52.dp, t, ac)
        Column(Modifier.weight(1f)) {
            Text(r.title, color = if (r.on) ac else Color.White, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(r.sub, color = Color.White.copy(alpha = .6f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        r.trail.forEach { (g, f) -> Text(g, Modifier.clickable(onClick = f).padding(10.dp), fontSize = 20.sp, color = ac) }
    }
}

@Composable
fun NowCard(st: Pst, t: Th, ac: Color, sz: Dp, onOpen: () -> Unit) {
    AnimatedVisibility(st.has && st.title.isNotBlank(), enter = slideInVertically { it } + fadeIn(), exit = fadeOut()) {
        Row(
            Modifier.fillMaxWidth().padding(10.dp).clip(RoundedCornerShape(t.r.dp)).background(t.panel).clickable(onClick = onOpen).padding(8.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Art(st.art, sz, t, ac)
            Column(Modifier.weight(1f)) {
                Text(st.title, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = (sz.value / 3.4f).coerceAtLeast(14f).sp)
                Text(st.artist, color = ac, fontSize = 12.sp, maxLines = 1)
            }
            Ico(if (st.playing) 1 else 0, (sz.value * .7f).dp, Color.White) { st.ctl?.let { if (it.isPlaying) it.pause() else it.play() } }
        }
    }
}

@Composable
fun SettingsPane(p: Profile, onSwitch: () -> Unit, onEdit: () -> Unit, onUpdate: (Profile) -> Unit, onClear: () -> Unit) {
    val ac = Color(p.accent)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Edit profile", true, ac, onEdit)
            Chip("Switch profile", false, ac, onSwitch)
        }
        Text("Theme", fontWeight = FontWeight.Bold)
        Chips(THEMES.map { it.name }, p.theme, ac) { onUpdate(p.copy(theme = it)) }
        Text("Animations", fontWeight = FontWeight.Bold)
        Chips(ANIMS, p.anim, ac) { onUpdate(p.copy(anim = it)) }
        Text("Layout", fontWeight = FontWeight.Bold)
        Chips(listOf("Spacious", "Compact"), if (p.compact) 1 else 0, ac) { onUpdate(p.copy(compact = it == 1)) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Menu click sound", Modifier.weight(1f))
            Switch(p.click, { onUpdate(p.copy(click = it)) }, colors = SwitchDefaults.colors(checkedTrackColor = ac))
        }
        Chip("Clear play history", false, ac, onClear)
        Text("Privacy", fontWeight = FontWeight.Bold)
        Text(
            "Serpent Player 1.0 works offline. Your music stays where it is; the app only keeps links and tags on this device. Profile photos, GIFs and backgrounds are copied into the app's private storage. Nothing is uploaded. The only network use is the Online page: it asks YouTube's public oEmbed service for a link's title and thumbnail, and plays through YouTube's official embedded player.",
            fontSize = 13.sp, color = Color.White.copy(alpha = .75f)
        )
    }
}

@Composable
fun Shell(p: Profile, onSwitch: () -> Unit, onEdit: () -> Unit, onUpdate: (Profile) -> Unit, onPlayed: (String) -> Unit) {
    val c = LocalContext.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    val t = THEMES[p.theme]
    val ac = Color(p.accent)
    val db = remember { Db(c) }
    var tracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    var recents by remember { mutableStateOf<List<Track>>(emptyList()) }
    var pls by remember { mutableStateOf<List<Pair<Long, String>>>(emptyList()) }
    var plTr by remember { mutableStateOf<List<Track>>(emptyList()) }
    var plId by remember { mutableStateOf<Long?>(null) }
    var loaded by remember { mutableStateOf(false) }
    var cat by remember { mutableIntStateOf(0) }
    var page by remember { mutableStateOf(false) }
    var sub by remember { mutableStateOf<Pair<Int, String>?>(null) }
    var q by remember { mutableStateOf("") }
    var prog by remember { mutableStateOf<String?>(null) }
    var full by remember { mutableStateOf(false) }
    var addFor by remember { mutableStateOf<Track?>(null) }
    var newName by remember { mutableStateOf<String?>(null) }
    val st = rememberPst { title, uri -> onPlayed(title); scope.launch(Dispatchers.IO) { db.hist(uri) } }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}

    suspend fun load() {
        val r = withContext(Dispatchers.IO) { Triple(db.all(), db.recents(), db.playlists()) }
        tracks = r.first; recents = r.second; pls = r.third
        plId?.let { id -> plTr = withContext(Dispatchers.IO) { db.plTracks(id) } }
        loaded = true
    }
    fun refresh() { scope.launch { load() } }
    fun tick() { if (p.click) view.playSoundEffect(SoundEffectConstants.CLICK) }
    fun fav(x: Track) { scope.launch { withContext(Dispatchers.IO) { db.fav(x.uri, !x.fav) }; load() } }
    LaunchedEffect(cat) { load() }
    val add = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            uris.forEachIndexed { i, u ->
                prog = "Adding ${i + 1} of ${uris.size}"
                withContext(Dispatchers.IO) { importOne(c, db, u) }
            }
            prog = null
            load()
        }
    }
    fun play(l: List<Track>, i: Int) {
        val m = st.ctl ?: return
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            perm.launch(Manifest.permission.POST_NOTIFICATIONS)
        m.setMediaItems(l.map { it.item() }, i, 0L)
        m.prepare()
        m.play()
    }
    fun tr(l: List<Track>, rem: ((Track) -> Unit)? = null): List<Rw> = l.mapIndexed { i, x ->
        Rw(x.title, x.artist, x.art, x.uri == st.id, buildList {
            add((if (x.fav) "♥" else "♡") to { fav(x) })
            if (rem != null) add("✕" to { rem(x) }) else add("+" to { addFor = x })
        }) { tick(); play(l, i) }
    }
    fun grp(kind: Int): List<Rw> = tracks.groupBy { if (kind == 0) it.album else it.artist }.map { (k, v) ->
        Rw(k, (if (kind == 0) v[0].artist + " · " else "") + "${v.size} tracks", v.firstNotNullOfOrNull { it.art }, false, emptyList()) { tick(); sub = kind to k }
    }

    val content: @Composable (Int) -> Unit = { cc ->
        val sb = if (cc == cat) sub else null
        if (CATS[cc] == "Settings") SettingsPane(p, onSwitch, onEdit, onUpdate) { scope.launch { withContext(Dispatchers.IO) { db.clearHist() }; load() } }
        else if (CATS[cc] == "Online") OnlinePane(p, db, st)
        else Column(Modifier.fillMaxSize()) {
            if (sb != null) Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Chip("‹ Back", false, ac) { sub = null }
                Text(sb.second, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1)
            } else if (cc == 0) {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) { Chip("Add songs", true, ac) { add.launch(arrayOf("audio/*")) } }
                OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp), singleLine = true, label = { Text("Search title or artist") })
            } else if (cc == 3) Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) { Chip("New playlist", true, ac) { newName = "" } }
            prog?.let { Text(it, color = ac, modifier = Modifier.padding(16.dp, 6.dp)) }
            val rws: List<Rw> = when {
                sb != null -> when (sb.first) {
                    0 -> tr(tracks.filter { it.album == sb.second })
                    1 -> tr(tracks.filter { it.artist == sb.second })
                    else -> tr(plTr) { x -> plId?.let { id -> scope.launch { withContext(Dispatchers.IO) { db.rmFrom(id, x.uri) }; load() } }; Unit }
                }
                cc == 0 -> tr(tracks.filter { q.isBlank() || it.title.contains(q, true) || it.artist.contains(q, true) })
                cc == 1 -> grp(0)
                cc == 2 -> grp(1)
                cc == 3 -> pls.map { (id, n) ->
                    Rw(n, "Playlist", null, false, listOf("✕" to { scope.launch { withContext(Dispatchers.IO) { db.delPl(id) }; load() }; Unit })) {
                        tick(); plId = id; sub = 2 to n; refresh()
                    }
                }
                cc == 5 -> tr(tracks.filter { it.fav })
                else -> tr(recents)
            }
            if (rws.isEmpty() && loaded) Text(
                when {
                    sb != null -> "Nothing here yet."
                    cc == 0 -> "No music yet. Tap Add songs and pick your files. Serpent Player only reads files you choose, so it needs no storage permission. Allow notifications so lock-screen controls can appear."
                    cc == 3 -> "No playlists yet. Tap New playlist, then use + on any song to add it."
                    cc == 5 -> "Tap the heart on any song to keep it here."
                    cc == 6 -> "Songs you play show up here."
                    else -> "Add songs in Music first."
                },
                color = Color.White.copy(alpha = .75f), modifier = Modifier.padding(24.dp)
            )
            LazyColumn(Modifier.weight(1f).fillMaxWidth()) { items(rws) { r -> RowItem(r, t, ac, p.compact) } }
        }
    }
    val header: @Composable () -> Unit = {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.clickable { onSwitch() }) { Avatar(p, 42.dp) }
            Column(Modifier.weight(1f)) {
                Text(p.name, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1)
                Text(t.name, color = ac, fontSize = 12.sp)
            }
        }
    }

    BackHandler(page || sub != null) { if (sub != null) sub = null else page = false }
    BackHandler(full) { full = false }
    val curTrack = tracks.firstOrNull { it.uri == st.id }
    Box(Modifier.fillMaxSize()) {
        Backdrop(p) {
            when (p.theme) {
                1 -> Column(Modifier.fillMaxSize()) {
                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        AnimatedContent(page, transitionSpec = {
                            if (p.anim == 0) EnterTransition.None togetherWith ExitTransition.None
                            else if (targetState) (slideInHorizontally { it } + fadeIn()) togetherWith (slideOutHorizontally { -it / 3 } + fadeOut())
                            else (slideInHorizontally { -it / 3 } + fadeIn()) togetherWith (slideOutHorizontally { it } + fadeOut())
                        }, label = "vita") { pg ->
                            Column(Modifier.fillMaxSize()) {
                                header()
                                if (!pg) LazyVerticalGrid(
                                    GridCells.Fixed(3), Modifier.weight(1f), contentPadding = PaddingValues(16.dp),
                                    horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(18.dp)
                                ) { itemsIndexed(CATS) { i, n -> Bubble(i, n, p.anim) { tick(); cat = i; sub = null; page = true } } }
                                else {
                                    Row(Modifier.padding(horizontal = 16.dp)) { Chip("‹ Home", false, ac) { sub = null; page = false } }
                                    Box(Modifier.weight(1f)) { content(cat) }
                                }
                            }
                        }
                    }
                    NowCard(st, t, ac, 44.dp) { full = true }
                }
                2 -> Column(Modifier.fillMaxSize()) {
                    header()
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        itemsIndexed(CATS) { i, n -> Chip(n, i == cat, ac) { tick(); cat = i; sub = null } }
                    }
                    NowCard(st, t, ac, 84.dp) { full = true }
                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        AnimatedContent(cat, transitionSpec = {
                            if (p.anim == 0) EnterTransition.None togetherWith ExitTransition.None
                            else (fadeIn(tween(300)) + scaleIn(initialScale = .96f)) togetherWith fadeOut(tween(150))
                        }, label = "ps5") { cc -> content(cc) }
                    }
                }
                else -> Column(Modifier.fillMaxSize()) {
                    header()
                    LazyRow(contentPadding = PaddingValues(horizontal = 12.dp)) {
                        itemsIndexed(CATS) { i, n -> XmbItem(n, i == cat, t, ac, p.anim) { tick(); cat = i; sub = null } }
                    }
                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        AnimatedContent(cat, transitionSpec = { fadeUp(p.anim) }, label = "xmb") { cc -> content(cc) }
                    }
                    NowCard(st, t, ac, 44.dp) { full = true }
                }
            }
            st.err?.let { Text(it, color = Color(0xFFFF8A8A), modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 80.dp, start = 16.dp, end = 16.dp)) }
        }
        AnimatedVisibility(full, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()) {
            Backdrop(p) { FullPlayer(st, p, t, ac, curTrack?.fav == true, { curTrack?.let { fav(it) } }) { full = false } }
        }
    }
    if (newName == null) addFor?.let { x ->
        AlertDialog(
            onDismissRequest = { addFor = null },
            confirmButton = { TextButton({ addFor = null }) { Text("Cancel") } },
            title = { Text("Add to playlist") },
            text = {
                Column {
                    pls.forEach { (id, n) -> TextButton({ scope.launch { withContext(Dispatchers.IO) { db.addTo(id, x.uri) }; load() }; addFor = null }) { Text(n) } }
                    TextButton({ newName = "" }) { Text("New playlist…") }
                }
            }
        )
    }
    newName?.let { nm ->
        AlertDialog(
            onDismissRequest = { newName = null },
            confirmButton = {
                TextButton({
                    val v = nm.trim()
                    val x = addFor
                    if (v.isNotEmpty()) scope.launch { withContext(Dispatchers.IO) { val id = db.newPl(v); if (x != null) db.addTo(id, x.uri) }; load() }
                    newName = null; addFor = null
                }) { Text("Create") }
            },
            dismissButton = { TextButton({ newName = null }) { Text("Cancel") } },
            title = { Text("New playlist") },
            text = { OutlinedTextField(nm, { newName = it }, singleLine = true, label = { Text("Name") }) }
        )
    }
}
