package com.y2k.player

import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.Drawable
import android.widget.ImageView
import androidx.activity.ComponentActivity
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun Media(path: String, mod: Modifier, play: Boolean = true) {
    val act = LocalContext.current as ComponentActivity
    var dr by remember(path) { mutableStateOf<Drawable?>(null) }
    LaunchedEffect(path) {
        dr = withContext(Dispatchers.IO) {
            try {
                ImageDecoder.decodeDrawable(ImageDecoder.createSource(File(path))) { d, i, _ ->
                    val m = maxOf(i.size.width, i.size.height)
                    if (m > 1080) d.setTargetSampleSize(m / 1080 + 1)
                }
            } catch (e: Exception) { null }
        }
    }
    DisposableEffect(dr, play) {
        val a = dr as? AnimatedImageDrawable
        a?.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
        val o = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME && play) a?.start() else if (e == Lifecycle.Event.ON_PAUSE) a?.stop()
        }
        if (play) a?.start()
        act.lifecycle.addObserver(o)
        onDispose { act.lifecycle.removeObserver(o); a?.stop() }
    }
    AndroidView(factory = { ImageView(it).apply { scaleType = ImageView.ScaleType.CENTER_CROP } }, modifier = mod, update = { it.setImageDrawable(dr) })
}

fun shp(s: Int, t: Th): Shape = when (s) { 0 -> RoundedCornerShape(4.dp); 2 -> CircleShape; else -> RoundedCornerShape(t.r.dp) }

@Composable
fun Avatar(p: Profile, sz: Dp) {
    val c = LocalContext.current
    val ac = Color(p.accent)
    val sh = shp(p.shape, THEMES[p.theme])
    Box(Modifier.size(sz).clip(sh).background(ac.copy(alpha = .35f)).border(2.dp, ac, sh), contentAlignment = Alignment.Center) {
        val pic = p.pic
        if (pic != null) Media(File(c.filesDir, pic).path, Modifier.fillMaxSize(), p.anim > 0)
        else Text((p.name.firstOrNull() ?: '+').uppercase(), color = Color.White, fontSize = (sz.value / 2.5f).sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Modifier.bob(i: Int, amp: Float = 6f, on: Boolean = true): Modifier {
    val b = rememberInfiniteTransition(label = "bob").animateFloat(-1f, 1f, infiniteRepeatable(tween(2600 + i * 300, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "b")
    return graphicsLayer { translationY = if (on) b.value * amp.dp.toPx() else 0f }
}

@Composable
fun Wordmark(sz: TextUnit) {
    Text(
        "SERPENT PLAYER 1.0", Modifier.bob(0, 5f),
        style = TextStyle(
            brush = Brush.horizontalGradient(listOf(Color(0xFF39FF14), Color(0xFF00E5FF), Color(0xFF8A2BE2))),
            fontFamily = SERPENT, fontSize = sz, letterSpacing = 3.sp
        )
    )
}

@Composable
fun Anim(th: Int, ac: Color, lv: Int) {
    val ph = rememberInfiniteTransition(label = "bg").animateFloat(0f, 1f, infiniteRepeatable(tween(if (lv == 1) 42000 else 24000, easing = LinearEasing)), label = "ph")
    val n = if (lv == 1) 7 else 14
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val p = ph.value
        val tau = 6.2831855f
        when (th) {
            0 -> {
                val bw = w / n * .5f
                for (i in 0 until n) {
                    val hh = h * (.22f + .2f * sin(tau * (p + i * .37f)))
                    val x = w * (i + .5f) / n
                    drawRect(Brush.verticalGradient(listOf(Color.Transparent, ac.copy(alpha = .22f)), h - hh, h), Offset(x - bw / 2, h - hh), Size(bw, hh))
                }
            }
            1 -> { for (i in 0 until n) {
                val sp = 1 + i % 3
                val y = h * (1.1f - ((p * sp + i * .13f) % 1f) * 1.2f)
                val x = w * ((i * .173f + .08f) % 1f) + 24f * sin(tau * p * sp + i)
                val r = (14 + (i * 7) % 26).dp.toPx()
                drawCircle(ac.copy(alpha = .16f), r, Offset(x, y))
                drawCircle(Color.White.copy(alpha = .22f), r, Offset(x, y), style = Stroke(2f))
            } }
            2 -> { for (k in 0..1) {
                val a = tau * p + k * 3.1416f
                val c = Offset(w * (.5f + .32f * cos(a)), h * (.35f + .18f * sin(a * (k + 1))))
                val col = if (k == 0) ac else Color(0xFF7B5CFF)
                drawRect(Brush.radialGradient(listOf(col.copy(alpha = .30f), Color.Transparent), c, w * .75f))
            } }
            else -> {
                val hz = h * .5f
                for (j in -6..6) drawLine(ac.copy(alpha = .2f), Offset(w / 2, hz), Offset(w / 2 + j * w * .22f, h), 2f)
                for (k in 0 until 8) {
                    val f = ((k + p) % 8f) / 8f
                    val y = hz + (h - hz) * f * f
                    drawLine(ac.copy(alpha = .08f + .3f * f), Offset(0f, y), Offset(w, y), 2f)
                }
                drawRect(Brush.verticalGradient(listOf(Color.Transparent, ac.copy(alpha = .14f)), hz - 90f, hz), Offset(0f, hz - 90f), Size(w, 90f))
            }
        }
        Unit
    }
}

@Composable
fun Backdrop(p: Profile, content: @Composable BoxScope.() -> Unit) {
    val c = LocalContext.current
    val t = THEMES[p.theme]
    val ac = Color(p.accent)
    Box(Modifier.fillMaxSize()) {
        val bm = p.bgm
        if (p.bg == 3 && bm != null) {
            Media(File(c.filesDir, bm).path, Modifier.fillMaxSize(), p.anim > 0)
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .5f)))
        } else {
            Canvas(Modifier.fillMaxSize()) {
                if (p.bg == 1) drawRect(t.bot) else drawRect(Brush.verticalGradient(listOf(t.top, t.bot)))
                if (p.bg == 2) {
                    val g = 48.dp.toPx()
                    var x = 0f
                    while (x < size.width) { drawLine(ac.copy(alpha = .12f), Offset(x, 0f), Offset(x, size.height)); x += g }
                    var y = 0f
                    while (y < size.height) { drawLine(ac.copy(alpha = .12f), Offset(0f, y), Offset(size.width, y)); y += g }
                }
            }
            if (p.anim > 0) Anim(p.theme, ac, p.anim)
        }
        Box(Modifier.fillMaxSize().systemBarsPadding()) {
            ProvideTextStyle(TextStyle(fontFamily = t.font, letterSpacing = t.ls.sp, color = Color.White)) { content() }
        }
    }
}
