package com.y2k.player

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class Ol(val id: String, val kind: Int, val title: String, val author: String, val art: String?, val url: String)

fun ytParse(raw: String): Pair<String?, String?>? {
    val u = try { Uri.parse(raw.trim()) } catch (e: Exception) { return null }
    val h = (u.host ?: return null).lowercase().removePrefix("www.")
    if (u.scheme?.startsWith("http") != true) return null
    if (h != "youtube.com" && h != "m.youtube.com" && h != "music.youtube.com" && h != "youtu.be") return null
    val list = u.getQueryParameter("list")?.takeIf { Regex("^[A-Za-z0-9_-]{6,64}$").matches(it) }
    var v = if (h == "youtu.be") u.pathSegments.firstOrNull() else u.getQueryParameter("v")
    if (v == null && u.pathSegments.firstOrNull() == "shorts") v = u.pathSegments.getOrNull(1)
    v = v?.takeIf { Regex("^[A-Za-z0-9_-]{11}$").matches(it) }
    return if (v == null && list == null) null else v to list
}

fun ytEmbed(v: String?, l: String?): String = when {
    l != null && v == null -> "https://www.youtube.com/embed/videoseries?list=$l&playsinline=1"
    l != null -> "https://www.youtube.com/embed/$v?list=$l&playsinline=1"
    else -> "https://www.youtube.com/embed/$v?playsinline=1"
}

fun ytCanon(id: String): String =
    if (id.startsWith("pl:")) "https://www.youtube.com/playlist?list=${id.drop(3)}" else "https://www.youtube.com/watch?v=${id.drop(2)}"

fun ytMeta(c: Context, canon: String, key: String): Triple<String, String, String?>? {
    try {
        val cn = URL("https://www.youtube.com/oembed?format=json&url=" + Uri.encode(canon)).openConnection() as HttpURLConnection
        cn.connectTimeout = 8000
        cn.readTimeout = 8000
        val j = JSONObject(cn.inputStream.bufferedReader().use { it.readText() })
        var art: String? = null
        val th = j.optString("thumbnail_url")
        if (th.isNotEmpty()) {
            val c2 = URL(th).openConnection() as HttpURLConnection
            c2.connectTimeout = 8000
            c2.readTimeout = 8000
            val bytes = c2.inputStream.use { it.readBytes() }
            val f = File(File(c.filesDir, "yt").apply { mkdirs() }, key.hashCode().toString() + ".jpg")
            f.writeBytes(bytes)
            art = f.path
        }
        return Triple(j.optString("title", canon), j.optString("author_name", ""), art)
    } catch (e: Exception) {
        return null
    }
}

@Composable
fun YtPlayer(url: String, mod: Modifier) {
    val act = LocalContext.current as ComponentActivity
    val holder = remember { arrayOfNulls<WebView>(1) }
    DisposableEffect(Unit) {
        val o = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_PAUSE) holder[0]?.onPause() else if (e == Lifecycle.Event.ON_RESUME) holder[0]?.onResume()
        }
        act.lifecycle.addObserver(o)
        onDispose {
            act.lifecycle.removeObserver(o)
            holder[0]?.let { it.stopLoading(); it.loadUrl("about:blank"); it.destroy() }
            holder[0] = null
        }
    }
    AndroidView(
        factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean =
                        request?.url?.host?.endsWith("youtube.com") != true
                }
                setBackgroundColor(android.graphics.Color.BLACK)
                loadUrl(url)
                holder[0] = this
            }
        },
        modifier = mod
    )
}

@Composable
fun OnlinePane(p: Profile, db: Db, st: Pst) {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    val t = THEMES[p.theme]
    val ac = Color(p.accent)
    var items by remember { mutableStateOf<List<Ol>>(emptyList()) }
    var link by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf<Ol?>(null) }
    suspend fun reload() { items = withContext(Dispatchers.IO) { db.onlineAll() } }
    LaunchedEffect(Unit) { reload() }
    BackHandler(playing != null) { playing = null }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(link, { link = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Paste a YouTube video or playlist link") })
            Chip(if (busy) "Saving…" else "Save link", true, ac) {
                if (!busy) {
                    val parsed = ytParse(link)
                    if (parsed == null) msg = "That doesn't look like a YouTube video or playlist link."
                    else {
                        busy = true
                        scope.launch {
                            val v = parsed.first
                            val l = parsed.second
                            val id = if (l != null) "pl:$l" else "v:$v"
                            if (withContext(Dispatchers.IO) { db.onlineHas(id) }) msg = "Already saved."
                            else {
                                val meta = withContext(Dispatchers.IO) { ytMeta(c, ytCanon(id), id) }
                                val title = meta?.first ?: (if (l != null) "YouTube playlist" else "YouTube video")
                                withContext(Dispatchers.IO) { db.onlinePut(Ol(id, if (l != null) 1 else 0, title, meta?.second ?: "", meta?.third, ytEmbed(v, l))) }
                                msg = if (meta == null) "Saved. Couldn't fetch the title (offline, private, or blocked)." else "Saved."
                                link = ""
                                reload()
                            }
                            busy = false
                        }
                    }
                }
            }
            Text(
                msg ?: "Links are saved on this device. Playback uses YouTube's official embedded player, so it only runs while this screen is open. Some videos block embedding; use Open in YouTube for those.",
                fontSize = 12.sp, color = Color.White.copy(alpha = .7f)
            )
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            items(items) { o ->
                RowItem(
                    Rw(o.title, o.author.ifEmpty { if (o.kind == 1) "Playlist" else "Video" }, o.art, false, listOf(
                        "↗" to {
                            try { c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(ytCanon(o.id)))) } catch (e: Exception) { msg = "No app can open this link." }
                        },
                        "✕" to {
                            scope.launch { withContext(Dispatchers.IO) { db.onlineDel(o.id); o.art?.let { File(it).delete() } }; reload() }
                            Unit
                        }
                    )) { st.ctl?.pause(); playing = o },
                    t, ac, p.compact
                )
            }
        }
    }
    playing?.let { o ->
        Column(Modifier.fillMaxSize().background(Color(0xFF0B0C10))) {
            Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Chip("‹ Back", false, ac) { playing = null }
                Chip("Open in YouTube", false, ac) {
                    try { c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(ytCanon(o.id)))) } catch (e: Exception) {}
                }
            }
            Text(o.title, Modifier.padding(horizontal = 16.dp, vertical = 4.dp), maxLines = 2, fontSize = 15.sp)
            YtPlayer(o.url, Modifier.fillMaxWidth().weight(1f))
        }
    }
}
